from quize_creator.pdf_to_text_Conversion import pdftotxt
import wikipedia as wiki
import os
from nltk.corpus import wordnet
import nltk
import random
import re
import numpy as np
from nltk.tokenize import word_tokenize
from nltk.tag import pos_tag


def de_emojify(text):
    regrex_pattern = re.compile(pattern="["
                                        u"\U0001F600-\U0001F64F"  # emoticons
                                        u"\U0001F300-\U0001F5FF"  # symbols & pictographs
                                        u"\U0001F680-\U0001F6FF"  # transport & map symbols
                                        u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
                                        "]+", flags=re.UNICODE)
    return regrex_pattern.sub(r'', text)


def namedentitylist(tuplelist):
    entity = []
    for tuplist in tuplelist:
        for tup in tuplist:
            entity.append(tup[1])
    entity_set = set(entity)
    entity_dict = dict()
    for ent in entity_set:
        entity_dict[ent] = list()
    for tuplist in tuplelist:
        for tup in tuplist:
            entity_dict[tup[1]].append(tup[0])

    return entity_dict


def mcq_maker(sent_with_tags, tag_dict, tag_to_focus):
    flag = True
    question = ""
    correct = ""
    for word, tag in sent_with_tags:
        wordforque = word
        if tag == tag_to_focus and flag:
            correct = wordforque
            wordforque = "________"
            flag = False
        question = question + " " + wordforque
    question = question + "."
    options = []
    option_number = random.randint(0, 5)
    for i in range(6):
        option = list(set(tag_dict[tag_to_focus]))[random.randint(0, len(set(tag_dict[tag_to_focus])) - 1)]
        while option == correct:
            option = list(set(tag_dict[tag_to_focus]))[random.randint(0, len(set(tag_dict[tag_to_focus])) - 1)]
        if i == option_number:
            option = correct
        options.append(option)

    return question, options, correct


def wordtagger(sents):
    # print(sents)
    if not isinstance(sents, list):
        sents = [sents]
    sentwithtags = []
    for sent in sents:
        sentword = nltk.word_tokenize(sent)
        sentwithtags.append(nltk.pos_tag(sentword))
    return sentwithtags


def paratosent(para):
    sent = para.split(". ")
    return sent


def similar_words(word):
    synonyms = []

    for syn in wordnet.synsets(word):
        for l in syn.lemmas():
            if l.antonyms() is not True:
                synonyms.append(l.name())

    return list(set(synonyms))


def opposit_words(word):
    antonyms = []

    for syn in wordnet.synsets(word):
        for l in syn.lemmas():
            if l.antonyms():
                antonyms.append(l.antonyms()[0].name())

    return list(set(antonyms))


path_directory = "book"
# pdftotxt(source=path_directory)

files = [path_directory + "/" + str(x) for x in os.listdir(path_directory)]

totalcontent = ""
for file in files:
    try:
        content = open(file).read()
        totalcontent += content
    except:
        print("Cant open the ", file)
totalcontent = de_emojify(totalcontent.replace("\n", " "))
sent = paratosent(totalcontent)

sent_with_tags = wordtagger(sent)
namedlistwithtags = namedentitylist(sent_with_tags)
# print(sent_with_tags[42])
tags= ["NN", "NNP", "NNS", "NNPS", "JJ"]
k = 0
for i in range(len(sent_with_tags)):

    question, options, correct = mcq_maker(sent_with_tags[i], namedlistwithtags, tags[random.randint(0, len(tags)-1)])
    if correct == "":
        pass
    else:
        print("_____________________________________________________")
        print("Question ", k + 1, ".", question)
        print("1. ", options[0])
        print("2. ", options[1])
        print("3. ", options[2])
        print("4. ", options[3])
        print("5. ", options[4])
        print("Correct Answer is --> ", correct)
        k += 1
# print(similar_words(correct))
# print(sent_with_tags[24])
